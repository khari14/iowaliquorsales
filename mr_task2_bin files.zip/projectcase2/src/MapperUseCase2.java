import java.io.IOException;
import org.apache.hadoop.hbase.mapreduce.TableMapper;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

public class MapperUseCase2 extends TableMapper<Text, FloatWritable> {

	private Text outString = new Text();
	private FloatWritable outNumber = new FloatWritable();

	public void map(ImmutableBytesWritable row, Result value, Context context)
			throws IOException, InterruptedException {
		String val = new String(value.getValue(Bytes.toBytes("is"), Bytes.toBytes("county")));
		String vol = new String(value.getValue(Bytes.toBytes("is"), Bytes.toBytes("bottles_sold")));
		outString.set(val);
		outNumber.set(Float.parseFloat(vol));

		context.write(outString, outNumber);
	}

}
