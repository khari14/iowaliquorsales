import java.io.IOException;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.NullWritable;

public class ReducerUseCase2 extends Reducer<Text, FloatWritable, WriteOutUseCase2, NullWritable> {

	public void reduce(Text key, Iterable<FloatWritable> values, Context context)
			throws IOException, InterruptedException {

		int sum = 0;
		for (FloatWritable val : values) {
			sum += val.get();
		}
		try {
			context.write(new WriteOutUseCase2(key.toString(), sum), NullWritable.get());
		} catch (IOException f) {
			f.printStackTrace();
		} catch (InterruptedException f) {
			f.printStackTrace();
		}
	}
}
