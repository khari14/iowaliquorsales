import java.io.IOException;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.mapreduce.TableMapReduceUtil;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.db.DBConfiguration;
import org.apache.hadoop.mapreduce.lib.db.DBOutputFormat;
import org.apache.hadoop.io.Text;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;

public class DriverUseCase1 {
	public static void main(String[] args) throws Exception {
		Configuration conf = HBaseConfiguration.create();
		DBConfiguration.configureDB(conf, "com.mysql.jdbc.Driver", "jdbc:mysql://localhost:3306/Test", "root", "1324"); // Configuring MySQL
		Job job = Job.getInstance(conf, "Average bottle_volume_ml sold in each city in IOWA State");
		job.setJarByClass(DriverUseCase1.class); // Line with Driver class

		Scan scan = new Scan();
		scan.setCaching(500); // default 1, Would be bad for MR Jobs
		scan.setCacheBlocks(false); // No True from MR jobs
		TableMapReduceUtil.initTableMapperJob("input_table", scan, MapperUseCase1.class, Text.class,
				FloatWritable.class, job);
		job.setReducerClass(ReducerUseCase1.class);
//		job.setMapOutputKeyClass(Text.class);
//		job.setMapOutputValueClass(FloatWritable.class);
		job.setOutputKeyClass(WriteOutUseCase1.class);
		job.setOutputValueClass(NullWritable.class);
		job.setOutputFormatClass(DBOutputFormat.class);
																																
		DBOutputFormat.setOutput(job, "case1", new String[] { "county", "avg_bottle_vol_ml" }); // Writing the job to MySQL
		job.setNumReduceTasks(1);
		boolean b = job.waitForCompletion(true);
		if (!b) {
			throw new IOException("error with job!");
		}
	}
}
